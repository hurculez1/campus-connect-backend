const { pool } = require('../config/database');

exports.getPosts = async (req, res, next) => {
    try {
        const { campus, tab } = req.query;
        let query = `
      SELECT p.*, u.first_name, u.profile_photo_url, u.university as user_campus
      FROM posts p
      LEFT JOIN users u ON p.user_id = u.id
      WHERE 1=1
    `;
        const params = [];

        if (campus && campus !== 'All Campuses') {
            query += ` AND p.campus = ?`;
            params.push(campus);
        }

        if (tab === 'Confessions') {
            query += ` AND p.is_anonymous = TRUE`;
        }

        if (tab === 'Trending') {
            query += ` ORDER BY p.likes_count DESC`;
        } else {
            query += ` ORDER BY p.created_at DESC`;
        }

        const [posts] = await pool.execute(query, params);
        res.json({ posts });
    } catch (error) {
        next(error);
    }
};

exports.createPost = async (req, res, next) => {
    try {
        const { content, campus, isAnonymous, type } = req.body;
        const userId = req.user.id;

        const [result] = await pool.execute(
            `INSERT INTO posts (user_id, content, campus, is_anonymous, type) 
       VALUES (?, ?, ?, ?, ?)`,
            [userId, content, campus, isAnonymous, type || 'general']
        );

        res.status(201).json({
            message: 'Post created',
            postId: result.insertId
        });
    } catch (error) {
        next(error);
    }
};

exports.likePost = async (req, res, next) => {
    try {
        const { postId } = req.params;
        await pool.execute(
            'UPDATE posts SET likes_count = likes_count + 1 WHERE id = ?',
            [postId]
        );
        res.json({ message: 'Post liked' });
    } catch (error) {
        next(error);
    }
};
