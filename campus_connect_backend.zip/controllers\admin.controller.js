const { pool } = require('../config/database');
const bcrypt = require('bcryptjs');
const { generateToken } = require('../middleware/auth.middleware');
const logger = require('../utils/logger');

exports.adminLogin = async (req, res, next) => {
  try {
    const { email, password } = req.body;

    const [admins] = await pool.execute(
      'SELECT * FROM admin_users WHERE email = ? AND is_active = TRUE',
      [email]
    );

    if (admins.length === 0) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }

    const admin = admins[0];
    const isValidPassword = await bcrypt.compare(password, admin.password_hash);

    if (!isValidPassword) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }

    await pool.execute(
      'UPDATE admin_users SET last_login = NOW() WHERE id = ?',
      [admin.id]
    );

    const token = generateToken(admin.id);

    res.json({
      token,
      admin: {
        id: admin.id,
        email: admin.email,
        firstName: admin.first_name,
        lastName: admin.last_name,
        role: admin.role
      }
    });
  } catch (error) {
    next(error);
  }
};

exports.getDashboardStats = async (req, res, next) => {
  try {
    // Total users
    const [userStats] = await pool.execute(`
      SELECT 
        COUNT(*) as total_users,
        SUM(CASE WHEN DATE(created_at) = CURDATE() THEN 1 ELSE 0 END) as new_today,
        SUM(CASE WHEN subscription_tier = 'premium' THEN 1 ELSE 0 END) as premium_users,
        SUM(CASE WHEN subscription_tier = 'vip' THEN 1 ELSE 0 END) as vip_users,
        SUM(CASE WHEN last_active >= DATE_SUB(NOW(), INTERVAL 24 HOUR) THEN 1 ELSE 0 END) as active_24h
      FROM users
    `);

    // Total matches
    const [matchStats] = await pool.execute(`
      SELECT 
        COUNT(*) as total_matches,
        SUM(CASE WHEN DATE(created_at) = CURDATE() THEN 1 ELSE 0 END) as matches_today
      FROM matches
    `);

    // Revenue
    const [revenueStats] = await pool.execute(`
      SELECT 
        SUM(CASE WHEN status = 'completed' THEN amount ELSE 0 END) as total_revenue,
        SUM(CASE WHEN status = 'completed' AND DATE(created_at) = CURDATE() THEN amount ELSE 0 END) as revenue_today
      FROM payments
    `);

    // Pending verifications
    const [pendingVerifications] = await pool.execute(`
      SELECT COUNT(*) as count FROM university_verifications WHERE status = 'pending'
    `);

    // Recent reports
    const [recentReports] = await pool.execute(`
      SELECT r.*, u1.first_name as reporter_name, u2.first_name as reported_name
      FROM reports r
      JOIN users u1 ON r.reporter_id = u1.id
      JOIN users u2 ON r.reported_id = u2.id
      WHERE r.status = 'pending'
      ORDER BY r.created_at DESC LIMIT 5
    `);

    res.json({
      users: userStats[0],
      matches: matchStats[0],
      revenue: revenueStats[0],
      pendingVerifications: pendingVerifications[0].count,
      recentReports
    });
  } catch (error) {
    next(error);
  }
};

exports.getUsers = async (req, res, next) => {
  try {
    const { page = 1, limit = 20, search, status, verification } = req.query;
    const offset = (page - 1) * limit;

    let query = `
      SELECT u.id, u.email, u.first_name, u.last_name, u.university, 
             u.subscription_tier, u.verification_status, u.is_active, u.is_banned,
             u.created_at, u.last_active,
             (SELECT COUNT(*) FROM matches WHERE user1_id = u.id OR user2_id = u.id) as match_count
      FROM users u
      WHERE 1=1
    `;
    const params = [];

    if (search) {
      query += ` AND (u.email LIKE ? OR u.first_name LIKE ? OR u.last_name LIKE ?)`;
      params.push(`%${search}%`, `%${search}%`, `%${search}%`);
    }

    if (status === 'banned') {
      query += ` AND u.is_banned = TRUE`;
    } else if (status === 'active') {
      query += ` AND u.is_active = TRUE AND u.is_banned = FALSE`;
    }

    if (verification) {
      query += ` AND u.verification_status = ?`;
      params.push(verification);
    }

    query += ` ORDER BY u.created_at DESC LIMIT ? OFFSET ?`;
    params.push(parseInt(limit), parseInt(offset));

    const [users] = await pool.execute(query, params);

    // Get total count
    let countQuery = `SELECT COUNT(*) as total FROM users u WHERE 1=1`;
    if (search) countQuery += ` AND (u.email LIKE '%${search}%' OR u.first_name LIKE '%${search}%' OR u.last_name LIKE '%${search}%')`;
    if (status === 'banned') countQuery += ` AND u.is_banned = TRUE`;
    if (status === 'active') countQuery += ` AND u.is_active = TRUE AND u.is_banned = FALSE`;
    if (verification) countQuery += ` AND u.verification_status = '${verification}'`;

    const [countResult] = await pool.execute(countQuery);

    res.json({
      users,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total: countResult[0].total
      }
    });
  } catch (error) {
    next(error);
  }
};

exports.banUser = async (req, res, next) => {
  try {
    const { userId } = req.params;
    const { reason, duration } = req.body;

    await pool.execute(
      `UPDATE users SET is_banned = TRUE, ban_reason = ? WHERE id = ?`,
      [reason, userId]
    );

    // Log action
    await pool.execute(
      `INSERT INTO activity_logs (admin_id, action, entity_type, entity_id, details)
       VALUES (?, 'ban_user', 'user', ?, ?)`,
      [req.user.id, userId, JSON.stringify({ reason, duration })]
    );

    logger.info(`User banned: ${userId} by admin ${req.user.id}`);

    res.json({ message: 'User banned successfully' });
  } catch (error) {
    next(error);
  }
};

exports.unbanUser = async (req, res, next) => {
  try {
    const { userId } = req.params;

    await pool.execute(
      `UPDATE users SET is_banned = FALSE, ban_reason = NULL WHERE id = ?`,
      [userId]
    );

    await pool.execute(
      `INSERT INTO activity_logs (admin_id, action, entity_type, entity_id, details)
       VALUES (?, 'unban_user', 'user', ?, ?)`,
      [req.user.id, userId, '{}']
    );

    res.json({ message: 'User unbanned successfully' });
  } catch (error) {
    next(error);
  }
};

exports.getVerifications = async (req, res, next) => {
  try {
    const { status = 'pending' } = req.query;

    const [verifications] = await pool.execute(`
      SELECT uv.*, u.first_name, u.last_name, u.email, u.profile_photo_url
      FROM university_verifications uv
      JOIN users u ON uv.user_id = u.id
      WHERE uv.status = ?
      ORDER BY uv.created_at DESC
    `, [status]);

    res.json({ verifications });
  } catch (error) {
    next(error);
  }
};

exports.reviewVerification = async (req, res, next) => {
  try {
    const { verificationId } = req.params;
    const { status, notes } = req.body;

    await pool.execute(
      `UPDATE university_verifications 
       SET status = ?, admin_reviewed_by = ?, admin_reviewed_at = NOW(), ai_verification_notes = ?
       WHERE id = ?`,
      [status, req.user.id, notes, verificationId]
    );

    // Update user verification status
    const [verifications] = await pool.execute(
      'SELECT user_id FROM university_verifications WHERE id = ?',
      [verificationId]
    );

    if (verifications.length > 0) {
      await pool.execute(
        `UPDATE users SET verification_status = ? WHERE id = ?`,
        [status, verifications[0].user_id]
      );
    }

    res.json({ message: 'Verification reviewed' });
  } catch (error) {
    next(error);
  }
};

exports.getReports = async (req, res, next) => {
  try {
    const { status = 'pending' } = req.query;

    const [reports] = await pool.execute(`
      SELECT r.*, 
             u1.first_name as reporter_name, u1.email as reporter_email,
             u2.first_name as reported_name, u2.email as reported_email
      FROM reports r
      JOIN users u1 ON r.reporter_id = u1.id
      JOIN users u2 ON r.reported_id = u2.id
      WHERE r.status = ?
      ORDER BY r.created_at DESC
    `, [status]);

    res.json({ reports });
  } catch (error) {
    next(error);
  }
};

exports.resolveReport = async (req, res, next) => {
  try {
    const { reportId } = req.params;
    const { resolution, action } = req.body;

    await pool.execute(
      `UPDATE reports 
       SET status = 'resolved', resolution_notes = ?, resolved_by = ?, resolved_at = NOW()
       WHERE id = ?`,
      [resolution, req.user.id, reportId]
    );

    // Get report details
    const [reports] = await pool.execute(
      'SELECT reported_id FROM reports WHERE id = ?',
      [reportId]
    );

    // Take action if specified
    if (action === 'ban' && reports.length > 0) {
      await pool.execute(
        'UPDATE users SET is_banned = TRUE, ban_reason = ? WHERE id = ?',
        [resolution, reports[0].reported_id]
      );
    }

    res.json({ message: 'Report resolved' });
  } catch (error) {
    next(error);
  }
};